# TrendInsight - 年齢・属性別トレンド分析ツール

YouTubeトレンド・Googleトレンド・人気サイトなどのデータを年齢・性別別に収集・可視化するWebアプリケーション。

## 機能

- **Google Trends統合** - 検索トレンドデータを日別・週別・月別で集計表示
- **YouTube Data API統合** - トレンド動画や人気コンテンツの統計情報を取得
- **年齢・性別フィルタリング** - 7段階の年齢層（13-17, 18-24, 25-34, 35-44, 45-54, 55-64, 65+）と性別で分析
- **ダッシュボード** - YouTubeデザインの洗練されたUI
- **分析履歴** - 過去のトレンド推移を比較可能
- **データキャッシング** - API呼び出しを最適化

## 技術スタック

- **フロントエンド**: React 19 + Tailwind CSS 4 + Vite
- **バックエンド**: Express 4 + tRPC 11
- **データベース**: MySQL/TiDB + Drizzle ORM
- **認証**: Manus OAuth
- **テスト**: Vitest

## セットアップ

### 前提条件

- Node.js 22.13.0以上
- pnpm 10.4.1以上
- MySQL/TiDBデータベース

### インストール

```bash
# 依存パッケージのインストール
pnpm install

# データベーススキーマの初期化
pnpm drizzle-kit generate
pnpm drizzle-kit migrate

# 開発サーバーの起動
pnpm dev
```

### 環境変数

`.env`ファイルに以下の環境変数を設定してください：

```env
DATABASE_URL=mysql://user:password@host:port/database
JWT_SECRET=your_jwt_secret
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
```

## 使用方法

1. **ホームページ** - ログイン後、自動的にダッシュボードにリダイレクト
2. **Google Trendsタブ** - キーワードを入力して検索トレンドを取得
3. **YouTubeトレンドタブ** - YouTube APIキーを入力してトレンド動画を取得
4. **フィルタリング** - 年齢層と性別を選択して属性別分析を実行

## API仕様

### tRPC Procedures

#### `trends.fetchGoogleTrends`
Google Trendsからトレンドデータを取得

**パラメータ:**
- `keyword: string` - 検索キーワード
- `region: string` - 地域コード（デフォルト: "JP"）
- `timeframe: string` - 期間（"daily" | "weekly" | "monthly" | "yearly"）
- `ageGroup?: string` - 年齢層フィルタ
- `gender?: string` - 性別フィルタ

**戻り値:**
```typescript
{
  keyword: string;
  timeframe: string;
  data: Array<{
    date: string;
    value: number;
    ageGroupData?: Record<string, number>;
    genderData?: Record<string, number>;
  }>;
}
```

#### `trends.fetchYouTubeTrending`
YouTubeトレンド動画を取得

**パラメータ:**
- `apiKey: string` - YouTube Data API キー
- `region: string` - 地域コード（デフォルト: "JP"）
- `maxResults: number` - 取得件数（デフォルト: 20）
- `ageGroup?: string` - 年齢層フィルタ
- `gender?: string` - 性別フィルタ

**戻り値:**
```typescript
{
  region: string;
  maxResults: number;
  videos: Array<{
    videoId: string;
    title: string;
    channelTitle: string;
    viewCount: number;
    likeCount: number;
    publishedAt: string;
    ageGroupData?: Record<string, number>;
    genderData?: Record<string, number>;
  }>;
}
```

## データベーススキーマ

### テーブル一覧

- **users** - ユーザー情報（Manus OAuth連携）
- **trendData** - トレンドデータ保存
- **analysisHistory** - 分析クエリ履歴
- **apiCache** - API呼び出し結果キャッシュ

## テスト

```bash
# ユニットテスト実行
pnpm test

# テストファイル例
server/trends.test.ts
server/auth.logout.test.ts
```

## ビルド・デプロイ

```bash
# 本番ビルド
pnpm build

# 本番サーバー起動
pnpm start
```

## 注意事項

### APIキー入力方式
- Google Trends APIとYouTube Data APIのキーはユーザーが都度入力する仕様
- APIキーはセッションストレージに一時保存
- ページリロード時に再入力が必要

### データシミュレーション
- 現在、年齢・性別別データはシミュレーション層で生成
- 実際のAPIデータと統合する際は、`server/trends.ts`の`simulateAgeGroupData`と`simulateGenderData`関数を置き換え

### キャッシング
- API呼び出し結果は6時間キャッシュ
- キャッシュキーは`{dataType}_{region}_{maxResults}_{ageGroup}_{gender}`

## トラブルシューティング

### YouTube APIエラー
- APIキーが有効か確認
- YouTube Data API v3が有効になっているか確認
- クォータ制限に達していないか確認

### データベース接続エラー
- DATABASE_URLが正しいか確認
- ユーザー名・パスワードが正しいか確認
- データベースが起動しているか確認

### リダイレクト無限ループ
- ブラウザキャッシュをクリア
- ログアウトして再ログイン

## 今後の改善予定

1. **実データAPI統合** - Google Trends APIとYouTube Analytics APIを実装
2. **レポートエクスポート** - PDF/CSV形式でのダウンロード・メール送信
3. **複数キーワード比較** - 複数キーワードの同時検索・比較機能
4. **リアルタイム更新** - WebSocketによるライブトレンド表示

## ライセンス

MIT

## サポート

問題が発生した場合は、GitHubのIssuesセクションで報告してください。
