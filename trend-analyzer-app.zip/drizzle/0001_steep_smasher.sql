CREATE TABLE `analysisHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`queryKeywords` text,
	`filters` text,
	`resultSummary` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analysisHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `apiCache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cacheKey` varchar(255) NOT NULL,
	`dataType` enum('google_trends','youtube_trending') NOT NULL,
	`cachedData` text NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `apiCache_id` PRIMARY KEY(`id`),
	CONSTRAINT `apiCache_cacheKey_unique` UNIQUE(`cacheKey`)
);
--> statement-breakpoint
CREATE TABLE `trendData` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`keyword` varchar(255) NOT NULL,
	`dataType` enum('google_trends','youtube_trending') NOT NULL,
	`region` varchar(10) DEFAULT 'JP',
	`timeframe` enum('daily','weekly','monthly','yearly') DEFAULT 'daily',
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`rawData` text,
	`aggregatedData` text,
	`ageGroupData` text,
	`genderData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trendData_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `analysisHistory` ADD CONSTRAINT `analysisHistory_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trendData` ADD CONSTRAINT `trendData_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;