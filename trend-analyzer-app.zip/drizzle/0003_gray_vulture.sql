ALTER TABLE `trendData` MODIFY COLUMN `rawData` longtext;--> statement-breakpoint
ALTER TABLE `trendData` MODIFY COLUMN `aggregatedData` mediumtext;--> statement-breakpoint
ALTER TABLE `trendData` MODIFY COLUMN `ageGroupData` mediumtext;--> statement-breakpoint
ALTER TABLE `trendData` MODIFY COLUMN `genderData` mediumtext;