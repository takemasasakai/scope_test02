import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, mediumtext, longtext } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * トレンドデータを保存するテーブル
 * Google Trends APIから取得した検索トレンド情報
 */
export const trendData = mysqlTable("trendData", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  keyword: varchar("keyword", { length: 255 }).notNull(),
  dataType: mysqlEnum("dataType", ["google_trends", "youtube_trending"]).notNull(),
  region: varchar("region", { length: 10 }).default("JP"),
  timeframe: mysqlEnum("timeframe", ["daily", "weekly", "monthly", "yearly"]).default("daily"),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  rawData: longtext("rawData"), // JSON形式で生データを保存
  aggregatedData: mediumtext("aggregatedData"), // JSON形式で集計済みデータを保存
  ageGroupData: mediumtext("ageGroupData"), // JSON形式で年齢別データを保存
  genderData: mediumtext("genderData"), // JSON形式で性別別データを保存
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TrendData = typeof trendData.$inferSelect;
export type InsertTrendData = typeof trendData.$inferInsert;

/**
 * 分析クエリの履歴を保存するテーブル
 * ユーザーが実行した検索・分析クエリを記録
 */
export const analysisHistory = mysqlTable("analysisHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  queryKeywords: text("queryKeywords"), // JSON配列で複数キーワードを保存
  filters: text("filters"), // JSON形式でフィルター条件を保存
  resultSummary: text("resultSummary"), // 分析結果のサマリー
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalysisHistory = typeof analysisHistory.$inferSelect;
export type InsertAnalysisHistory = typeof analysisHistory.$inferInsert;

/**
 * キャッシュテーブル
 * API呼び出し結果をキャッシュして、不要なAPI呼び出しを削減
 */
export const apiCache = mysqlTable("apiCache", {
  id: int("id").autoincrement().primaryKey(),
  cacheKey: varchar("cacheKey", { length: 255 }).notNull().unique(),
  dataType: mysqlEnum("dataType", ["google_trends", "youtube_trending"]).notNull(),
  cachedData: mediumtext("cachedData").notNull(), // JSON形式でキャッシュデータを保存
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ApiCache = typeof apiCache.$inferSelect;
export type InsertApiCache = typeof apiCache.$inferInsert;