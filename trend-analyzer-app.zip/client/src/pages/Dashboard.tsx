import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Loader2, Search } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [keyword, setKeyword] = useState("");
  const [youtubeApiKey, setYoutubeApiKey] = useState("");
  const [selectedTimeframe, setSelectedTimeframe] = useState<"daily" | "weekly" | "monthly" | "yearly">("weekly");
  const [selectedRegion, setSelectedRegion] = useState("JP");
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string | undefined>();
  const [selectedGender, setSelectedGender] = useState<string | undefined>();
  const [hasResults, setHasResults] = useState(false);
  const [activeTab, setActiveTab] = useState("google");

  // API呼び出し
  const fetchGoogleTrendsMutation = trpc.trends.fetchGoogleTrends.useMutation();
  const fetchYouTubeMutation = trpc.trends.fetchYouTubeTrending.useMutation();
  const getHistoryQuery = trpc.trends.getHistory.useQuery({ limit: 10 });

  // サンプルデータ（デモ用）
  const sampleTrendData = [
    { date: "2026-03-15", value: 45, trend: "up" },
    { date: "2026-03-16", value: 52, trend: "up" },
    { date: "2026-03-17", value: 48, trend: "down" },
    { date: "2026-03-18", value: 61, trend: "up" },
    { date: "2026-03-19", value: 58, trend: "down" },
  ];

  const sampleAgeData = [
    { name: "13-17", value: 25 },
    { name: "18-24", value: 30 },
    { name: "25-34", value: 20 },
    { name: "35-44", value: 15 },
    { name: "45-54", value: 7 },
    { name: "55-64", value: 2 },
    { name: "65+", value: 1 },
  ];

  const sampleGenderData = [
    { name: "Male", value: 50 },
    { name: "Female", value: 50 },
  ];

  const COLORS = ["#FF0000", "#CC0000", "#990000", "#660000"];

  const handleFetchGoogleTrends = async () => {
    if (!keyword.trim()) return;
    try {
      await fetchGoogleTrendsMutation.mutateAsync({
        keyword,
        region: selectedRegion,
        timeframe: selectedTimeframe,
        ageGroup: selectedAgeGroup as any,
        gender: selectedGender as any,
      });
      setHasResults(true);
    } catch (error) {
      console.error("Failed to fetch trends:", error);
    }
  };

  const handleFetchYouTube = async () => {
    if (!youtubeApiKey.trim()) return;
    try {
      await fetchYouTubeMutation.mutateAsync({
        apiKey: youtubeApiKey,
        region: selectedRegion,
        maxResults: 20,
        ageGroup: selectedAgeGroup as any,
        gender: selectedGender as any,
      });
      setHasResults(true);
    } catch (error) {
      console.error("Failed to fetch YouTube:", error);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ヘッダー */}
      <header className="border-b border-border bg-white sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-accent">TrendInsight</h1>
            <div className="text-sm text-muted-foreground">
              {user?.name || user?.email}
            </div>
          </div>
        </div>
      </header>

      <main className="container py-6 md:py-8 space-y-8">
        {/* 検索セクション */}
        <section className="space-y-4">
          <div>
            <h2 className="text-2xl font-bold mb-4">トレンド検索</h2>
          </div>

          {/* タブ選択 */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="google">Google トレンド</TabsTrigger>
              <TabsTrigger value="youtube">YouTube トレンド</TabsTrigger>
            </TabsList>

            <TabsContent value="google" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Google検索フォーム */}
                <div className="md:col-span-2 card-youtube space-y-4">
                  <div>
                    <Label htmlFor="keyword" className="text-sm font-medium">
                      検索キーワード
                    </Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        id="keyword"
                        placeholder="検索したいキーワードを入力"
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && handleFetchGoogleTrends()}
                      />
                      <Button
                        onClick={handleFetchGoogleTrends}
                        disabled={fetchGoogleTrendsMutation.isPending || !keyword.trim()}
                        className="btn-youtube-primary"
                      >
                        {fetchGoogleTrendsMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Search className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="region" className="text-sm font-medium">
                        地域
                      </Label>
                      <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                        <SelectTrigger id="region" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="JP">日本</SelectItem>
                          <SelectItem value="US">アメリカ</SelectItem>
                          <SelectItem value="GB">イギリス</SelectItem>
                          <SelectItem value="DE">ドイツ</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="timeframe" className="text-sm font-medium">
                        期間
                      </Label>
                      <Select value={selectedTimeframe} onValueChange={(v) => setSelectedTimeframe(v as any)}>
                        <SelectTrigger id="timeframe" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">日別</SelectItem>
                          <SelectItem value="weekly">週別</SelectItem>
                          <SelectItem value="monthly">月別</SelectItem>
                          <SelectItem value="yearly">年別</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* フィルタセクション */}
                <div className="card-youtube space-y-4">
                  <div>
                    <Label htmlFor="age-group" className="text-sm font-medium">
                      年齢層
                    </Label>
                    <Select value={selectedAgeGroup || "all"} onValueChange={(v) => setSelectedAgeGroup(v === "all" ? undefined : v)}>
                      <SelectTrigger id="age-group" className="mt-2">
                        <SelectValue placeholder="すべて" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">すべて</SelectItem>
                        <SelectItem value="13-17">13-17歳</SelectItem>
                        <SelectItem value="18-24">18-24歳</SelectItem>
                        <SelectItem value="25-34">25-34歳</SelectItem>
                        <SelectItem value="35-44">35-44歳</SelectItem>
                        <SelectItem value="45-54">45-54歳</SelectItem>
                        <SelectItem value="55-64">55-64歳</SelectItem>
                        <SelectItem value="65+">65歳以上</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="gender" className="text-sm font-medium">
                      性別
                    </Label>
                    <Select value={selectedGender || "all"} onValueChange={(v) => setSelectedGender(v === "all" ? undefined : v)}>
                      <SelectTrigger id="gender" className="mt-2">
                        <SelectValue placeholder="すべて" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">すべて</SelectItem>
                        <SelectItem value="male">男性</SelectItem>
                        <SelectItem value="female">女性</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="youtube" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* YouTube API キー入力 */}
                <div className="md:col-span-2 card-youtube space-y-4">
                  <div>
                    <Label htmlFor="youtube-key" className="text-sm font-medium">
                      YouTube API キー
                    </Label>
                    <Input
                      id="youtube-key"
                      type="password"
                      placeholder="APIキーを入力"
                      value={youtubeApiKey}
                      onChange={(e) => setYoutubeApiKey(e.target.value)}
                      className="mt-2"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="region-yt" className="text-sm font-medium">
                        地域
                      </Label>
                      <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                        <SelectTrigger id="region-yt" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="JP">日本</SelectItem>
                          <SelectItem value="US">アメリカ</SelectItem>
                          <SelectItem value="GB">イギリス</SelectItem>
                          <SelectItem value="DE">ドイツ</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* フィルタセクション */}
                <div className="card-youtube space-y-4">
                  <div>
                    <Label htmlFor="age-group-yt" className="text-sm font-medium">
                      年齢層
                    </Label>
                    <Select value={selectedAgeGroup || "all"} onValueChange={(v) => setSelectedAgeGroup(v === "all" ? undefined : v)}>
                      <SelectTrigger id="age-group-yt" className="mt-2">
                        <SelectValue placeholder="すべて" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">すべて</SelectItem>
                        <SelectItem value="13-17">13-17歳</SelectItem>
                        <SelectItem value="18-24">18-24歳</SelectItem>
                        <SelectItem value="25-34">25-34歳</SelectItem>
                        <SelectItem value="35-44">35-44歳</SelectItem>
                        <SelectItem value="45-54">45-54歳</SelectItem>
                        <SelectItem value="55-64">55-64歳</SelectItem>
                        <SelectItem value="65+">65歳以上</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="gender-yt" className="text-sm font-medium">
                      性別
                    </Label>
                    <Select value={selectedGender || "all"} onValueChange={(v) => setSelectedGender(v === "all" ? undefined : v)}>
                      <SelectTrigger id="gender-yt" className="mt-2">
                        <SelectValue placeholder="すべて" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">すべて</SelectItem>
                        <SelectItem value="male">男性</SelectItem>
                        <SelectItem value="female">女性</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={handleFetchYouTube}
                    disabled={fetchYouTubeMutation.isPending || !youtubeApiKey.trim()}
                    className="btn-youtube-primary w-full"
                  >
                    {fetchYouTubeMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    YouTube トレンド取得
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* 分析結果セクション */}
        {hasResults && (
          <section className="space-y-4">
            <div>
              <h2 className="text-2xl font-bold mb-4">分析結果</h2>
              {selectedAgeGroup || selectedGender ? (
                <p className="text-sm text-muted-foreground mb-4">
                  フィルタ: {selectedAgeGroup && `年齢層 ${selectedAgeGroup}`}
                  {selectedAgeGroup && selectedGender && " / "}
                  {selectedGender && `性別 ${selectedGender === "male" ? "男性" : "女性"}`}
                </p>
              ) : null}
            </div>

            <Tabs defaultValue="trend" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="trend">トレンド推移</TabsTrigger>
                <TabsTrigger value="age">年齢別分析</TabsTrigger>
                <TabsTrigger value="gender">性別分析</TabsTrigger>
              </TabsList>

              <TabsContent value="trend" className="space-y-4 mt-4">
                <Card className="card-youtube">
                  <h3 className="text-lg font-semibold mb-4">
                    検索トレンド推移
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={sampleTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                      <YAxis stroke="var(--muted-foreground)" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                        }}
                      />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="var(--accent)"
                        strokeWidth={2}
                        dot={{ fill: "var(--accent)", r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>
              </TabsContent>

              <TabsContent value="age" className="space-y-4 mt-4">
                <Card className="card-youtube">
                  <h3 className="text-lg font-semibold mb-4">
                    年齢層別検索関心度
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={sampleAgeData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                      <YAxis stroke="var(--muted-foreground)" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                        }}
                      />
                      <Bar dataKey="value" fill="var(--accent)" />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              </TabsContent>

              <TabsContent value="gender" className="space-y-4 mt-4">
                <Card className="card-youtube">
                  <h3 className="text-lg font-semibold mb-4">
                    性別別検索関心度
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={sampleGenderData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {sampleGenderData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </Card>
              </TabsContent>
            </Tabs>
          </section>
        )}

        {/* 初期状態のメッセージ */}
        {!hasResults && (
          <section className="flex flex-col items-center justify-center py-16 text-center">
            <div className="text-6xl mb-4">📊</div>
            <h3 className="text-2xl font-bold mb-2">検索結果がありません</h3>
            <p className="text-muted-foreground mb-6">
              上記のフォームからキーワードを検索して、トレンドデータを表示してください
            </p>
          </section>
        )}

        {/* 分析履歴セクション */}
        <section className="space-y-4">
          <div>
            <h2 className="text-2xl font-bold mb-4">分析履歴</h2>
          </div>

          <Card className="card-youtube">
            {getHistoryQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-accent" />
              </div>
            ) : getHistoryQuery.data?.data && getHistoryQuery.data.data.length > 0 ? (
              <div className="space-y-2">
                {getHistoryQuery.data.data.map((item, index) => (
                  <div key={index} className="flex items-center justify-between py-3 border-b border-border/30 last:border-b-0 hover:bg-muted/50 px-2 rounded transition-colors">
                    <div>
                      <p className="font-medium text-sm">
                        {item.resultSummary || "分析クエリ"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.createdAt).toLocaleString("ja-JP")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                分析履歴がありません
              </p>
            )}
          </Card>
        </section>
      </main>

      {/* フッター */}
      <footer className="border-t border-border bg-muted/30 py-6 mt-12">
        <div className="container">
          <p className="text-center text-sm text-muted-foreground">
            © 2026 TrendInsight. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
