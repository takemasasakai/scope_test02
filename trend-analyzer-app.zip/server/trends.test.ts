import { describe, expect, it } from "vitest";
import {
  simulateAgeGroupDistribution,
  simulateGenderDistribution,
  aggregateTrendData,
} from "./trends";

describe("Trends Module", () => {
  describe("simulateAgeGroupDistribution", () => {
    it("should return age group distribution for anime keyword", () => {
      const result = simulateAgeGroupDistribution({}, "anime");

      expect(result).toHaveProperty("13-17");
      expect(result).toHaveProperty("18-24");
      expect(result).toHaveProperty("25-34");
      expect(result).toHaveProperty("35-44");
      expect(result).toHaveProperty("45-54");
      expect(result).toHaveProperty("55-64");
      expect(result).toHaveProperty("65+");

      // 若年層向けキーワードなので13-17と18-24が高い
      expect(result["13-17"]).toBe(25);
      expect(result["18-24"]).toBe(30);
    });

    it("should return age group distribution for news keyword", () => {
      const result = simulateAgeGroupDistribution({}, "news");

      // 中高年層向けキーワードなので35-44が最も高い
      expect(result["35-44"]).toBe(25);
      expect(result["13-17"]).toBe(5);
    });

    it("should return default distribution for neutral keyword", () => {
      const result = simulateAgeGroupDistribution({}, "weather");

      // デフォルト均等分布
      Object.values(result).forEach((value) => {
        expect(value).toBe(14);
      });
    });

    it("should sum to approximately 100", () => {
      const result = simulateAgeGroupDistribution({}, "test");
      const sum = Object.values(result).reduce((a, b) => a + b, 0);
      expect(sum).toBeGreaterThan(95);
      expect(sum).toBeLessThan(105);
    });
  });

  describe("simulateGenderDistribution", () => {
    it("should return balanced gender distribution by default", () => {
      const result = simulateGenderDistribution({}, "general");

      expect(result.male).toBe(50);
      expect(result.female).toBe(50);
    });

    it("should skew female for beauty keyword", () => {
      const result = simulateGenderDistribution({}, "beauty");

      expect(result.female).toBe(75);
      expect(result.male).toBe(25);
    });

    it("should skew male for sports keyword", () => {
      const result = simulateGenderDistribution({}, "sports");

      expect(result.male).toBe(70);
      expect(result.female).toBe(30);
    });

    it("should sum to 100", () => {
      const result = simulateGenderDistribution({}, "test");
      expect(result.male + result.female).toBe(100);
    });
  });

  describe("aggregateTrendData", () => {
    it("should return default structure for null data", () => {
      const result = aggregateTrendData(null, "daily");

      expect(result).toHaveProperty("timeline");
      expect(result).toHaveProperty("aggregated");
      expect(result).toHaveProperty("trend");
      expect(result).toHaveProperty("timeframe");
      expect(result.timeframe).toBe("daily");
    });

    it("should aggregate data correctly", () => {
      const testData = {
        interestOverTime: [
          { value: 10 },
          { value: 20 },
          { value: 30 },
        ],
      };

      const result = aggregateTrendData(testData, "weekly");

      expect(result.aggregated).toBe(60);
      expect(result.timeframe).toBe("weekly");
    });

    it("should handle different timeframes", () => {
      const testData = { interestOverTime: [] };

      const dailyResult = aggregateTrendData(testData, "daily");
      const monthlyResult = aggregateTrendData(testData, "monthly");

      expect(dailyResult.timeframe).toBe("daily");
      expect(monthlyResult.timeframe).toBe("monthly");
    });
  });
});
