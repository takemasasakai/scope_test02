/**
 * Google Trends API と YouTube Data API の統合ロジック
 */

import { getCache, saveCache } from "./db";

/**
 * 年齢層の型定義
 */
export type AgeGroup = "13-17" | "18-24" | "25-34" | "35-44" | "45-54" | "55-64" | "65+";
export type Gender = "male" | "female";

/**
 * Google Trends APIからトレンドデータを取得
 */
export async function fetchGoogleTrends(
  keyword: string,
  apiKey: string,
  region: string = "JP",
  timeframe: "daily" | "weekly" | "monthly" | "yearly" = "daily",
  ageGroup?: AgeGroup,
  gender?: Gender
): Promise<any> {
  const cacheKey = `google_trends_${keyword}_${region}_${timeframe}_${ageGroup || "all"}_${gender || "all"}`;

  // キャッシュを確認
  const cached = await getCache(cacheKey);
  if (cached) {
    return JSON.parse(cached.cachedData);
  }

  try {
    // Google Trends API呼び出し
    const response = await fetch(
      `https://trends.google.com/trends/api/explore?hl=ja&tz=-540&req=${encodeURIComponent(
        JSON.stringify({
          comparisonItem: [{ keyword, geo: region }],
          category: 0,
          property: "",
        })
      )}`
    );

    if (!response.ok) {
      throw new Error(`Google Trends API error: ${response.statusText}`);
    }

    const text = await response.text();
    // Google Trends APIは先頭に)]}' が付いているため削除
    const jsonStr = text.replace(/^\)\]\}'\n/, "");
    const data = JSON.parse(jsonStr);

    // キャッシュに保存（24時間有効）
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await saveCache({
      cacheKey,
      dataType: "google_trends",
      cachedData: JSON.stringify(data),
      expiresAt,
    });

    return data;
  } catch (error) {
    console.error("Failed to fetch Google Trends:", error);
    throw error;
  }
}

/**
 * YouTube Data APIからトレンド動画を取得
 */
export async function fetchYouTubeTrending(
  apiKey: string,
  region: string = "JP",
  maxResults: number = 20,
  ageGroup?: AgeGroup,
  gender?: Gender
): Promise<any> {
  const cacheKey = `youtube_trending_${region}_${maxResults}_${ageGroup || "all"}_${gender || "all"}`;

  // キャッシュを確認
  const cached = await getCache(cacheKey);
  if (cached) {
    return JSON.parse(cached.cachedData);
  }

  try {
    // YouTube Data API呼び出し
    const url = new URL("https://www.googleapis.com/youtube/v3/videos");
    url.searchParams.set("part", "snippet,statistics,contentDetails");
    url.searchParams.set("chart", "mostPopular");
    url.searchParams.set("regionCode", region === "JP" ? "JP" : region);
    url.searchParams.set("maxResults", maxResults.toString());
    url.searchParams.set("key", apiKey);
    url.searchParams.set("hl", "ja");

    const response = await fetch(url.toString());

    if (!response.ok) {
      throw new Error(`YouTube API error: ${response.statusText}`);
    }

    const data = await response.json();

    // キャッシュに保存（6時間有効）
    const expiresAt = new Date(Date.now() + 6 * 60 * 60 * 1000);
    await saveCache({
      cacheKey,
      dataType: "youtube_trending",
      cachedData: JSON.stringify(data),
      expiresAt,
    });

    return data;
  } catch (error) {
    console.error("Failed to fetch YouTube Trending:", error);
    throw error;
  }
}

/**
 * YouTube動画の詳細統計情報を取得
 */
export async function fetchYouTubeVideoStats(
  videoIds: string[],
  apiKey: string
): Promise<any> {
  try {
    const url = new URL("https://www.googleapis.com/youtube/v3/videos");
    url.searchParams.set("part", "statistics,snippet");
    url.searchParams.set("id", videoIds.join(","));
    url.searchParams.set("key", apiKey);

    const response = await fetch(url.toString());

    if (!response.ok) {
      throw new Error(`YouTube API error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Failed to fetch YouTube video stats:", error);
    throw error;
  }
}

/**
 * APIキーの有効性を検証
 */
export async function validateGoogleTrendsKey(apiKey: string): Promise<boolean> {
  try {
    // シンプルなテストリクエストを送信
    const response = await fetch(
      `https://trends.google.com/trends/api/explore?hl=ja&tz=-540&req=${encodeURIComponent(
        JSON.stringify({
          comparisonItem: [{ keyword: "test" }],
          category: 0,
          property: "",
        })
      )}`
    );

    // Google Trends APIはAPIキーを使わないため、常に成功
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * YouTube APIキーの有効性を検証
 */
export async function validateYouTubeKey(apiKey: string): Promise<boolean> {
  try {
    const url = new URL("https://www.googleapis.com/youtube/v3/videos");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("chart", "mostPopular");
    url.searchParams.set("regionCode", "JP");
    url.searchParams.set("maxResults", "1");
    url.searchParams.set("key", apiKey);

    const response = await fetch(url.toString());
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.warn("YouTube API validation error:", response.status, errorData);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error("YouTube API validation exception:", error);
    return false;
  }
}

/**
 * トレンドデータを年齢層別にシミュレート
 * 実際のAPIでは年齢別データが提供されないため、
 * 統計的な分布パターンを使用してシミュレート
 */
export function simulateAgeGroupDistribution(
  baseData: any,
  keyword: string
): Record<string, number> {
  // キーワードの特性に基づいて年齢分布をシミュレート
  const ageGroups = {
    "13-17": 0,
    "18-24": 0,
    "25-34": 0,
    "35-44": 0,
    "45-54": 0,
    "55-64": 0,
    "65+": 0,
  };

  // キーワードの特性に基づいた分布パターン
  const keywordLower = keyword.toLowerCase();

  if (
    keywordLower.includes("anime") ||
    keywordLower.includes("game") ||
    keywordLower.includes("tiktok")
  ) {
    // 若年層向けキーワード
    ageGroups["13-17"] = 25;
    ageGroups["18-24"] = 30;
    ageGroups["25-34"] = 20;
    ageGroups["35-44"] = 15;
    ageGroups["45-54"] = 7;
    ageGroups["55-64"] = 2;
    ageGroups["65+"] = 1;
  } else if (
    keywordLower.includes("news") ||
    keywordLower.includes("politics") ||
    keywordLower.includes("economy")
  ) {
    // 中高年層向けキーワード
    ageGroups["13-17"] = 5;
    ageGroups["18-24"] = 10;
    ageGroups["25-34"] = 20;
    ageGroups["35-44"] = 25;
    ageGroups["45-54"] = 20;
    ageGroups["55-64"] = 15;
    ageGroups["65+"] = 5;
  } else {
    // デフォルト均等分布
    Object.keys(ageGroups).forEach((key) => {
      ageGroups[key as keyof typeof ageGroups] = 14;
    });
  }

  return ageGroups;
}

/**
 * トレンドデータを性別別にシミュレート
 */
export function simulateGenderDistribution(
  baseData: any,
  keyword: string
): Record<string, number> {
  const genderData = {
    male: 50,
    female: 50,
  };

  // キーワードの特性に基づいて性別分布をシミュレート
  const keywordLower = keyword.toLowerCase();

  if (
    keywordLower.includes("beauty") ||
    keywordLower.includes("fashion") ||
    keywordLower.includes("makeup")
  ) {
    genderData.female = 75;
    genderData.male = 25;
  } else if (
    keywordLower.includes("sports") ||
    keywordLower.includes("gaming") ||
    keywordLower.includes("tech")
  ) {
    genderData.male = 70;
    genderData.female = 30;
  }

  return genderData;
}

/**
 * トレンドデータを集計・正規化
 */
export function aggregateTrendData(
  rawData: any,
  timeframe: "daily" | "weekly" | "monthly" | "yearly"
): any {
  // データ形式に応じた集計処理
  if (!rawData) {
    return {
      timeline: [],
      aggregated: 0,
      trend: "stable",
      timeframe,
    };
  }

  // 簡単な集計例
  return {
    timeline: rawData.timeline || [],
    aggregated: rawData.interestOverTime?.reduce((sum: number, item: any) => sum + (item.value || 0), 0) || 0,
    trend: "stable",
    timeframe,
  };
}
