import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  fetchGoogleTrends,
  fetchYouTubeTrending,
  validateGoogleTrendsKey,
  validateYouTubeKey,
  simulateAgeGroupDistribution,
  simulateGenderDistribution,
  aggregateTrendData,
  type AgeGroup,
  type Gender,
} from "./trends";
import {
  saveTrendData,
  getTrendData,
  saveAnalysisHistory,
  getAnalysisHistory,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * トレンド分析API
   */
  trends: router({
    /**
     * Google Trends データを取得
     */
    fetchGoogleTrends: protectedProcedure
      .input(
        z.object({
          keyword: z.string().min(1),
          region: z.string().default("JP"),
          timeframe: z.enum(["daily", "weekly", "monthly", "yearly"]).default("daily"),
          ageGroup: z.enum(["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"]).optional(),
          gender: z.enum(["male", "female"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const data = await fetchGoogleTrends(
            input.keyword,
            "", // Google Trends APIはAPIキーを使わない
            input.region,
            input.timeframe,
            input.ageGroup as AgeGroup | undefined,
            input.gender as Gender | undefined
          );

          // 年齢・性別別のシミュレーションデータを生成
          const ageGroupData = simulateAgeGroupDistribution(data, input.keyword);
          const genderData = simulateGenderDistribution(data, input.keyword);
          const aggregated = aggregateTrendData(data, input.timeframe);

          // データベースに保存
          await saveTrendData({
            userId: ctx.user.id,
            keyword: input.keyword,
            dataType: "google_trends",
            region: input.region,
            timeframe: input.timeframe,
            startDate: new Date(),
            endDate: new Date(),
            rawData: JSON.stringify(data),
            aggregatedData: JSON.stringify(aggregated),
            ageGroupData: JSON.stringify(ageGroupData),
            genderData: JSON.stringify(genderData),
          });

          return {
            success: true,
            data: {
              raw: data,
              aggregated,
              ageGroupData,
              genderData,
              filters: {
                ageGroup: input.ageGroup,
                gender: input.gender,
              },
            },
          };
        } catch (error) {
          console.error("Failed to fetch Google Trends:", error);
          throw new Error("Google Trends データの取得に失敗しました");
        }
      }),

    /**
     * YouTube トレンド動画を取得
     */
    fetchYouTubeTrending: protectedProcedure
      .input(
        z.object({
          apiKey: z.string().min(1),
          region: z.string().default("JP"),
          maxResults: z.number().int().min(1).max(50).default(20),
          ageGroup: z.enum(["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"]).optional(),
          gender: z.enum(["male", "female"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          // APIキーの有効性を検証
          const isValid = await validateYouTubeKey(input.apiKey);
          if (!isValid) {
            throw new Error("YouTube APIキーが無効です");
          }

          const data = await fetchYouTubeTrending(
            input.apiKey,
            input.region,
            input.maxResults,
            input.ageGroup as AgeGroup | undefined,
            input.gender as Gender | undefined
          );

          // 各動画のシミュレーション属性データを生成
          const videosWithAttributes = data.items?.map((item: any) => ({
            ...item,
            ageGroupData: simulateAgeGroupDistribution(item, item.snippet?.title || ""),
            genderData: simulateGenderDistribution(item, item.snippet?.title || ""),
          })) || [];

          // データベースに保存
          await saveTrendData({
            userId: ctx.user.id,
            keyword: "youtube_trending",
            dataType: "youtube_trending",
            region: input.region,
            timeframe: "daily",
            startDate: new Date(),
            endDate: new Date(),
            rawData: JSON.stringify(data),
            aggregatedData: JSON.stringify(videosWithAttributes),
            ageGroupData: JSON.stringify({}),
            genderData: JSON.stringify({}),
          });

          return {
            success: true,
            data: {
              videos: videosWithAttributes,
              totalResults: data.pageInfo?.totalResults || 0,
              filters: {
                ageGroup: input.ageGroup,
                gender: input.gender,
              },
            },
          };
        } catch (error) {
          console.error("Failed to fetch YouTube Trending:", error);
          throw new Error("YouTube トレンド動画の取得に失敗しました");
        }
      }),

    /**
     * 分析履歴を取得
     */
    getHistory: protectedProcedure
      .input(
        z.object({
          limit: z.number().int().min(1).max(100).default(20),
        })
      )
      .query(async ({ input, ctx }) => {
        try {
          const history = await getAnalysisHistory(ctx.user.id, input.limit);
          return {
            success: true,
            data: history,
          };
        } catch (error) {
          console.error("Failed to get analysis history:", error);
          throw new Error("分析履歴の取得に失敗しました");
        }
      }),

    /**
     * 分析クエリを保存
     */
    saveAnalysis: protectedProcedure
      .input(
        z.object({
          queryKeywords: z.array(z.string()),
          filters: z.record(z.string(), z.any()),
          resultSummary: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          await saveAnalysisHistory({
            userId: ctx.user.id,
            queryKeywords: JSON.stringify(input.queryKeywords),
            filters: JSON.stringify(input.filters),
            resultSummary: input.resultSummary,
          });

          return {
            success: true,
          };
        } catch (error) {
          console.error("Failed to save analysis:", error);
          throw new Error("分析の保存に失敗しました");
        }
      }),

    /**
     * APIキーの有効性を検証
     */
    validateApiKey: publicProcedure
      .input(
        z.object({
          apiType: z.enum(["youtube", "googletrends"]),
          apiKey: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        try {
          let isValid = false;

          if (input.apiType === "youtube") {
            isValid = await validateYouTubeKey(input.apiKey);
          } else if (input.apiType === "googletrends") {
            isValid = await validateGoogleTrendsKey(input.apiKey);
          }

          return {
            success: true,
            isValid,
          };
        } catch (error) {
          console.error("Failed to validate API key:", error);
          return {
            success: false,
            isValid: false,
          };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
