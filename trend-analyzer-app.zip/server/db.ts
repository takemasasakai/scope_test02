import { and, desc, eq, gt, gte, lt, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, trendData, InsertTrendData, analysisHistory, InsertAnalysisHistory, apiCache, InsertApiCache } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * トレンドデータを取得
 */
export async function getTrendData(
  userId: number,
  keyword: string,
  dataType: "google_trends" | "youtube_trending",
  startDate: Date,
  endDate: Date
) {
  const db = await getDb();
  if (!db) return null;

  return await db
    .select()
    .from(trendData)
    .where(
      and(
        eq(trendData.userId, userId),
        eq(trendData.keyword, keyword),
        eq(trendData.dataType, dataType),
        gte(trendData.startDate, startDate),
        lte(trendData.endDate, endDate)
      )
    )
    .limit(1);
}

/**
 * トレンドデータを保存
 */
export async function saveTrendData(
  data: InsertTrendData
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db.insert(trendData).values(data);
  } catch (error) {
    console.error("[Database] Failed to save trend data:", error);
    throw error;
  }
}

/**
 * 分析履歴を取得
 */
export async function getAnalysisHistory(
  userId: number,
  limit: number = 20
) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(analysisHistory)
    .where(eq(analysisHistory.userId, userId))
    .orderBy(desc(analysisHistory.createdAt))
    .limit(limit);
}

/**
 * 分析履歴を保存
 */
export async function saveAnalysisHistory(
  data: InsertAnalysisHistory
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db.insert(analysisHistory).values(data);
  } catch (error) {
    console.error("[Database] Failed to save analysis history:", error);
    throw error;
  }
}

/**
 * キャッシュを取得
 */
export async function getCache(cacheKey: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(apiCache)
    .where(
      and(
        eq(apiCache.cacheKey, cacheKey),
        gt(apiCache.expiresAt, new Date())
      )
    )
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * キャッシュを保存
 */
export async function saveCache(
  data: InsertApiCache
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db.insert(apiCache).values(data).onDuplicateKeyUpdate({
      set: {
        cachedData: data.cachedData,
        expiresAt: data.expiresAt,
      },
    });
  } catch (error) {
    console.error("[Database] Failed to save cache:", error);
    throw error;
  }
}

/**
 * 期限切れのキャッシュを削除
 */
export async function cleanExpiredCache(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db
      .delete(apiCache)
      .where(lt(apiCache.expiresAt, new Date()));
  } catch (error) {
    console.error("[Database] Failed to clean expired cache:", error);
    throw error;
  }
}
